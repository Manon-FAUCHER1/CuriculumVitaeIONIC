import { Component, OnInit } from '@angular/core';
import { AlertController, PopoverController } from '@ionic/angular';

@Component({
  selector: 'app-profil-menu',
  templateUrl: './profil-menu.component.html',
  styleUrls: ['./profil-menu.component.scss'],
})
export class ProfilMenuComponent implements OnInit {

  public reseaux = [
    {icon: 'logo-google'},
    {icon: 'logo-twitter'}
  ];
  constructor(private alertController: AlertController) { }

  ngOnInit() {}

  async openAlert() {
    const myMessage = 'Etes vous sur de vouloir quitter l\'application ?';
    const alert = await this.alertController.create({
      message: myMessage,
      buttons: ['Annuler', 'Valider']
    });

    await alert.present();
    await alert.onDidDismiss();

  }

}
