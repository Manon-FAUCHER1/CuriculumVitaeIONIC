import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from '../model/user-model';

const url = 'http://localhost:3000/home';

@Injectable({
  providedIn: 'root'
})
export class ApiUserService {

  constructor(private http: HttpClient) {}

  public find(): Observable<UserModel[]> {
    return this.http.get<UserModel[]>(url);
  }

  public update(e: UserModel) {
    return this.http.put<UserModel>(url+'/'+e.id, e);
  }
}
