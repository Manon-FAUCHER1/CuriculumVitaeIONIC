import { Component, OnInit } from '@angular/core';
import { ProfilMenuComponent } from '../profil-menu/profil-menu.component';
import { OverlayEventDetail } from '@ionic/core';
import { PopoverController } from '@ionic/angular';
import { UserModel } from '../model/user-model';
import { ApiUserService } from '../service/api-user.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  user!: UserModel;

  informations = [
    {icon: 'home-outline', info: '57 Boulevard des Tribunes, 44300 Nantes'},
    {icon: 'mail-outline', info: 'manon.faucher.pro@gmail.com'},
    {icon: 'call-outline', info: '06.48.17.32.09'},
    {icon: 'car-outline', info: 'permis B'},
  ];

  constructor(private popover: PopoverController, private serviceUser: ApiUserService) {}

  ngOnInit(): void {

  }

  openMenu(myevent: MouseEvent) {
    this.popover
      .create({
        component: ProfilMenuComponent,
        showBackdrop: true,
        cssClass: 'my-menu-class',
        event: myevent
      })
      .then((popoverElement: HTMLIonPopoverElement) => {
        popoverElement.present();
      });
  }
}
