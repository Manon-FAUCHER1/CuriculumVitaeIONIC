import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-competences',
  templateUrl: './competences.page.html',
  styleUrls: ['./competences.page.scss'],
})
export class CompetencesPage implements OnInit {

  competences = [
    {title: 'Langages', list:[' Kotlin', ' Java', ' Php 7', ' JavaScript', ' Html 5', ' CSS', ' Sql', ' PL/Sql']},
    {title: 'Mobilité', list:[ ' Android', ' Application hybrid', ' Progressive Web Application (PWA)']},
    {title: 'IDE', list: [' Android studio',' Eclipse', ' Intellij Idea', ' PhpStorm', ' VSCode']},
    {title: 'SGBD', list: [' MySql', ' Oracle', ' Sql Server']},
    {title: 'Framework', list: ['Wordpress', ' Ionic', ' Angular', ' Bootstrap']},
    {title: 'Méthodologies', list: [' Agile / Scrum']},
    {title: 'Responsive', list: [' Bootstrap', ' Angular Materia']},
    {title: 'Outils / Divers', list: [' Gitlab', ' Git', ' Postman', ' ELK (Elastic Search, Logstash, Kibana)',
    ' Docker', ' Docker Compose']},
  ];

  constructor() { }

  ngOnInit() {
  }

}
