import { Component, OnInit } from '@angular/core';
import { FormationsModel } from '../model/formations-model';
import { ApiFormationsService } from '../service/api-formations.service';

@Component({
  selector: 'app-formations',
  templateUrl: './formations.page.html',
  styleUrls: ['./formations.page.scss'],
})
export class FormationsPage implements OnInit {

  listFormation!: FormationsModel[];

  public formations;

  constructor(private serviceFormations: ApiFormationsService) { }

  ngOnInit() {

    this.serviceFormations.findAll().subscribe(listF => this.listFormation = listF);
    this.formations = [
      {date: '2020-2021',
      title: 'Formation Concepteur Développeur d\'Applications Fullstack filière Java (Bac+3/4)',
      school: 'DIGINAMIC, 44800 Saint-Herblain',
      note: 'Concevoir et développer une interface utilisateur. Développement JAVA et gestion des données relationnelles'},
      {date: '2019-2020',
      title: 'Formation Développeur Web et Web Mobile (Bac+2)',
      school: 'ENI Ecole Informatique, 44800 Saint-Herblain',
      note: ''},
      {date: '2017-2018',
      title: 'BTS Système Numérique Informatique et Réseaux',
      school: 'Institut Catholique Supérieur St-André, 79000 Niort',
      note: ''},
      {date: '2017',
      title: 'BAC Professionnel Système Electroniques et Numériques Option Electronique Industrielle Embarqué',
      school: 'Lycée St-André, 79000 Niort',
      note: ''}
    ];
  }

}
