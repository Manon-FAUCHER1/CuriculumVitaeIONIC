import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experiences-others',
  templateUrl: './experiences-others.page.html',
  styleUrls: ['./experiences-others.page.scss'],
})
export class ExperiencesOthersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
