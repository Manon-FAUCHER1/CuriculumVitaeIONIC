import { ExperiencesModel } from './experiences-model';

describe('ExperiencesModel', () => {
  it('should create an instance', () => {
    expect(new ExperiencesModel()).toBeTruthy();
  });
});
