import { CompetencesModel } from './competences-model';

describe('CompetencesModel', () => {
  it('should create an instance', () => {
    expect(new CompetencesModel()).toBeTruthy();
  });
});
