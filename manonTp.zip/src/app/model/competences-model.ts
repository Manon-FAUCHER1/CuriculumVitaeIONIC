export class CompetencesModel {
  id = 0;
  title = '';
  languages = '';
}
