import { FormationsModel } from './formations-model';

describe('FormationsModel', () => {
  it('should create an instance', () => {
    expect(new FormationsModel()).toBeTruthy();
  });
});
