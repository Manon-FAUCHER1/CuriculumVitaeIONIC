export class FormationsModel {
  id = 0;
  obtentionDate = '';
  title = '';
  school = '';
}
