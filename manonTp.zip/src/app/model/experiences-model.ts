export class ExperiencesModel {
  id = 0;
  business = '';
  startDate = '';
  endDate = '';
  role = '';
}
