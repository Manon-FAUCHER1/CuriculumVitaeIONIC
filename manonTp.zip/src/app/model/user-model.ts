export class UserModel {
  id = 0;
  name = '';
  adress = '';
  mail = '';
  telephone = '';
  permis = '';
}
